<form action="<?php echo $_SERVER['SCRIPT_NAME']; ?>">
    <?php echo translate("Show bug statistics for the selected project"); ?>:
    <select name="projectid" onChange="document.location.href = '<?php echo $_SERVER['SCRIPT_NAME']; ?>?projectid=' + this.options[this.selectedIndex].value">
        <option value="0"><?php echo translate("All projects"); ?></option>
        <?php build_select('project', isset($_GET['projectid']) ? $_GET['projectid'] : ''); ?>
    </select>
    <input type="submit" value="<?php echo translate("Go"); ?>">
</form>

<h3><?php echo translate("Bug Resolutions"); ?></h3>
<table class="bordertable" cellpadding="4" cellspacing="0" align="center">
    <tr>
        <?php for ($i = 0, $count = count($resfields); $i < $count; $i++) { ?>
            <th><?php echo htmlspecialchars($resfields[$i]); ?></th>
        <?php } ?>
    </tr>
    <?php for ($i = 0, $count = count($developers); $i < $count; $i++) { ?>
        <tr>
            <?php foreach ($developers[$i] as $var => $val) { ?>
                <?php if ($var == "Assigned To") { ?>
                    <td><?php echo!empty($val) ? maskemail($val) : translate("Unassigned"); ?></td>
                <?php } else { ?>
                    <td align="center"><?php echo $val; ?></td>
                <?php } ?>
            <?php } ?>
        </tr>
    <?php } ?>
</table>
