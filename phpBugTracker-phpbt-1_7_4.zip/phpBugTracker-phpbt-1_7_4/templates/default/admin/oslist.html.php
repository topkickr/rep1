<script language="JavaScript">
<!--
    var me = '<?php echo $_SERVER['SCRIPT_NAME']; ?>';

    function popupOS(id) {
        window.open(me + '?op=edit&use_js=1&os_id=' + id, 'ewin', 'dependent=yes,width=350,height=300,scrollbars=1');
    }
// -->
</script>
<table border="0" width="100%">
    <tr>
        <td valign="top">
            <b>&nbsp;<?php echo $page_title; ?></b> - <a href="os.php?op=edit&os_id=0" onClick="popupOS(0);
                    return false;"><?php echo translate("Add new operating system"); ?></a>
            <hr size="1">
            <table class="bordertable" align="center">
                <tr>
                    <th class="<?php echo $headers['name']['class']; ?>"><a href="<?php echo $headers['name']['url']; ?>"><?php echo translate("Name"); ?></a></th>
                    <th class="<?php echo $headers['regex']['class']; ?>"><a href="<?php echo $headers['regex']['url']; ?>"><?php echo translate("Regex"); ?></a></th>
                    <th class="<?php echo $headers['sortorder']['class']; ?>"><a href="<?php echo $headers['sortorder']['url']; ?>"><?php echo translate("Sort Order"); ?></a></th>
                    <th>&nbsp;</th>
                </tr>
                <?php for ($i = 0, $count = count($oses); $i < $count; $i++) { ?>
                    <tr>
                        <td><a href="os.php?op=edit&os_id=<?php echo $oses[$i]['os_id']; ?>" onClick="popupOS(<?php echo $oses[$i]['os_id']; ?>);
                                    return false;"><?php echo htmlspecialchars($oses[$i]['os_name']); ?></a></td>
                        <td>&nbsp;<?php echo htmlspecialchars($oses[$i]['regex']); ?></td>
                        <td align="center"><?php echo $oses[$i]['sort_order']; ?></td>
                        <td align="center">
                            <?php if (!$oses[$i]['bug_count']) { ?>
                                <a href="os.php?op=del&os_id=<?php echo $oses[$i]['os_id']; ?>&ak=<?php echo make_action_key(); ?>" onClick="return confirm('<?php echo translate("Are you sure you want to delete this OS"); ?>?')"><?php echo translate("Delete"); ?></a>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </table>
            <?php include('pagination.html'); ?>
            <br>
            <div class="info">
                <?php echo translate("Items with a Sort Order = 0 will not be selectable by users."); ?>
                <br>
                <?php echo translate("Only those items that have no bugs referencing them can be deleted."); ?>
            </div>
        </td>
    </tr>
</table>
